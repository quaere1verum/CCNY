#include<iostream>
using namespace std;
int main(){
        string firstname = "Daniel";
		string lastname = "Alvarez Pajaro" ;
		string streetaddress = "39-35 51st street";
		string city = "Woodside";
		string state = "NY";
		string zipcode = "11377";
		cout<<firstname<<"\t"<<lastname<<endl<<streetaddress<<endl<<city<<", "<<state<<", "<<zipcode<<endl;
	    return 0;
}		
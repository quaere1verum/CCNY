#include<iostream>
using namespace std;
int main(){
         float C;
		 cout<<"\nEnter Celsius Degrees: ";
		 cin>>C;
		 float F = (9.0/5.0)*C + 32.0;
		 cout<<C<<" degrees Celsius is equivalent to "<<F<<" degrees Fahrenheit"<<endl;
		 return 0;
}
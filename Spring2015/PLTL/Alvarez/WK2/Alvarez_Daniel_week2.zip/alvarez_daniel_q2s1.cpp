#include<iostream>
using namespace std;
int main(){
         float C = 100;
		 float F = (9.0/5.0)*C + 32.0;
		 cout<<"\n100 degrees Celsius is equivalent to "<<F<<" degrees Fahrenheit"<<endl;
		 return 0;
}
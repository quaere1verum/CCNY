#include<iostream>
using namespace std;
int main(){
         float F;
		 cout<<"\nEnter Fahrenheit Degrees: ";
		 cin>>F;
		 float C = (F - 32.0)*(5.0/9.0);
		 cout<<F<<" degrees Fahrenheit is equivalent to "<<C<<" degrees Celsius"<<endl;
		 return 0;
}
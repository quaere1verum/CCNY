#include <iostream>

int main(){
		std::cout<<"Hello World!"<<std::endl;
		return 0;
}
		// The error message says expected constructor, destructor,
		// or type conversion before '<' token.
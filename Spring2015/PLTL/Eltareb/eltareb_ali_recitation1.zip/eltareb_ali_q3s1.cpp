#include <iostream>
int main(){
		std::string a;
		std::cout<<"What is your name?";
		std::cin>> a;
		std::cout<<"Hello"<<a;
		std::cout<<"!"<<std::endl;
		return 0;
		
}		
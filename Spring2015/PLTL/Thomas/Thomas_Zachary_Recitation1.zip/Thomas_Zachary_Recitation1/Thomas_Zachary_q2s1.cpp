#include <iostream>
using namespace std;
int main()
{
std::cout<<"Hello World!"<<std::endl;
return 0;
}
/*
Errors: line1- the include is not a datatype without a hashtag.
line3- Missing terminating character
line4- No end statement for return declaration.



*/
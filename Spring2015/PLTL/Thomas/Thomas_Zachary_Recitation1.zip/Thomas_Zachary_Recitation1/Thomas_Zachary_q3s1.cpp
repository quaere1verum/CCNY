#include <iostream>
using namespace std;
int main()
{
	string Zachary ;
	std::cout<<"Hello my name is !" ;
	std::cin>>Zachary ;
	
	
	return 0;
}
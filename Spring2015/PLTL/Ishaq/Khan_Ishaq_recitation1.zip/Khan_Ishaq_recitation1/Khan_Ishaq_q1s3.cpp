// Ishaq Khan//
#include <iostream>
int main(){
    std::cout<<"Hello my name is Ishaq!"<<std::endl;
    return 0;
}


#include <iostream>
int main(){
    std::cout<<"Hello my name is David!"<<std::endl;
    return 0;
}
// Ishaq Khan 
/*
include <iostream>
int main(){
	cout<<"Hello World!"<<std::endl;
	return 0
}
 */
	
/*
1. The error message says expescted constructor, destructor, or type conversion before '<' token
2. The error message is on line 1;
*/


#include <iostream>
int main(){
    std::cout<<"Hello World!"<<std::endl;
    return 0;
}



#include <iostream>

int main ()
{
	std::string i;
	std::cout<<"What is your name? ";
	std::cin >> i;
	std::cout<<"Hello "<<i;
	std::cout<<"!"<<std::endl;
	return 0;
}

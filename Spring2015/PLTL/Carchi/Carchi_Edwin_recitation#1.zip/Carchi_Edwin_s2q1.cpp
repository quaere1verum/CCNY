#include <iostream>
int main ()
{
	cout<<"Hello World!<<std::endl;
	
	return 0;
}

/*
The error message says:
'cout' was not declared in scope
missing terminating " character
expected primary-expression before "return"
expected ';' before "return"
Lines 4&6 contain error messages.
*/


/*
Kristy Calungsod
CSC 102 K2
Week 1: Hello World: Modify Hello World
*/
#include <iostream>

int main()
{
  std::cout << "Hello my name is Kristy!" << std::endl;
  return 0;
}
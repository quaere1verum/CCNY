/*
Kristy Calungsod
CSC 102 K2
Week 1: Hello World: Write Hello World
*/
#include <iostream>

int main()
{
  std::cout << "Hello World!" << std::endl;
  return 0;
}

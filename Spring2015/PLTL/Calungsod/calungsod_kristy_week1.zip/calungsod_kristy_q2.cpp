/*
Kristy Calungsod
CSC 102 K2
Week 1: Hello World: Debug Hello World
*/
#include <iostream>

int main()
{
  std::cout << "Hello World!" << std::endl;
  return 0;
}

/* Question 3:
3a) missing '#' before 'include'
    missing 'std::' before 'cout'
    missing '"' after 'World!'
    missing ';' after 'return 0'

3b) line 6
    line 10
    line 10
    line11
*/
